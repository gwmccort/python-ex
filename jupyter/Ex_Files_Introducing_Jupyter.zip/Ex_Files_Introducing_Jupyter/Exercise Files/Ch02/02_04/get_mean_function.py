def get_mean(column):
    return df[column].mean()
