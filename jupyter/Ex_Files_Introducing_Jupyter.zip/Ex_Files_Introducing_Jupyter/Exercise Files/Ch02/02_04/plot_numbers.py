import matplotlib.pyplot as plt
import sys

y=list(map(int,sys.argv[1:]))
plt.plot(y)
